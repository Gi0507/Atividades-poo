package com.clinica.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.clinica.Bean.Medico;

public class MedicoDAO{
        private String url = "jdbc:sqlite:database.db";
        private Connection conexao;
        
        public MedicoDAO() throws Exception{
        conexao = DriverManager.getConnection(url);
    
        String sql = """
                CREATE TABLE IF NOT EXISTS medico (
                    crm TEXT PRIMARY KEY,
                    cpf TEXT PRIMARY KEY,
                    nome TEXT NOT NULL,
                    especialidade TEXT NOT NULL
                )""";   
            
                
    
            Statement stmt = conexao.createStatement();
            stmt.execute(sql);
        }
    
        public void create(Medico obj) throws Exception{
            String sql = "insert into medico(crm, nome, especialidade,telefone) values(?,?,?,?)";
            PreparedStatement comandoSql = conexao.prepareStatement(sql);
            comandoSql.setString(1, obj.getCrm());
            comandoSql.setString(2, obj.getNome());
            comandoSql.setString(3, obj.getEspecialidade());
            comandoSql.setString(4, obj.getTelefone());
            comandoSql.executeUpdate();
        }
    
        
        public Medico read(String crm) throws  Exception{
            Medico obj = new Medico();
            String sql = "select * from medico where crm=?";
            PreparedStatement stmt = conexao.prepareStatement(sql);
            stmt.setString(1, crm);
    
            ResultSet resultado = stmt.executeQuery();
            if(!resultado.isClosed()){
                obj.setCrm(resultado.getString("crm"));
                obj.setNome(resultado.getString("nome"));
                obj.setEspecialidade(resultado.getString("especialidade"));
                obj.setTelefone(resultado.getString("telefone"));
            }
            return obj;
        }
}
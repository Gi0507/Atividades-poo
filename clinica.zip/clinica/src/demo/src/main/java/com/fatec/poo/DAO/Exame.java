public class Exame {
    
}

public class Trianglo extends figuras {
    private int arestas = 3;
    private int lados;
    private float altura;

    public float getAltura() {
        return altura;
    }   

    public int getLados() {
        return lados;
    }

    public void setLados(int lados) {
        this.lados = lados;
    }

    public Trianglo(int lados, float altura) {
        this.lados = lados;
        this.altura =  lados*2/3;
    }
 
}

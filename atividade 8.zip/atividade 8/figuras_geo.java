public interface figuras_geo {
    

    public int arestas();
    public double area();

}
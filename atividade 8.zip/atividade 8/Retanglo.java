public class Retanglo extends figuras {
    private int arestas = 4;
    private int lado_menor;
    private int lado_maior;


    public int getLado_menor() {
        return lado_menor;
    }
    public void setLado_menor(int lado_menor) {
        this.lado_menor = lado_menor;
    }

    public int getLado_maior() {
        return lado_maior;
    }
    public void setLado_maior(int lado_maior) {
        this.lado_maior = lado_maior;
    }

    public Retanglo(int lado_menor, int lado_maior) {
        this.lado_menor = lado_menor;
        this.lado_maior = lado_maior;
    }
    public double area() {
        return getLado_menor() * getLado_maior();
    }

}

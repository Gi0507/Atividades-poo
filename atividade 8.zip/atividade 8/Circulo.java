public class Circulo extends figuras {
    private int raio;
    private int arestas=0;
    

    public int getRaio() {
        return raio;
    }
    public void setRaio(int raio) {
        this.raio = raio;
    }

    public Circulo(int raio) {
        this.raio = raio;
    }
    public double area() {
        int raio = getRaio();
        double area= 3.14 *raio *raio;
        return area;
    }
}

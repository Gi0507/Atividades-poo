public class Quadrado extends figuras {

    private int arestas = 4;
    private int lados;
    
    
    public int getLados() {
        return lados;
    }
    public void setLados(int lados) {
        this.lados = lados;
    }



    public Quadrado(int lados) {
        this.lados = lados;
    }
    public double area() {
        double area = getLados() * getLados();
        return area;
    }

}

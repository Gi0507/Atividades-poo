public class figuras  implements figuras_geo{
    private int arestas;
    
    
    public int getArestas() {
        return arestas;
    }
    public void setArestas(int arestas) {
        this.arestas = arestas;
    }

    @Override
    public int arestas() {
        return getArestas();
    }

    @Override
    public double area() {
        int area = 0;
        return area;
    }

}

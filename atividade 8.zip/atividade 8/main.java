public class main {
    public static void main(String[] args) {
        Circulo c1 = new Circulo(5);
        System.out.println("A área do círculo é: " + c1.area());
        Quadrado q1 = new Quadrado(4);
        System.out.println("A área do quadrado é: " + q1.area());
        Retanglo r1 = new Retanglo(4, 5);
        System.out.println("A área do retângulo é: " + r1.area());
        Trianglo t1 = new Trianglo(3, 4); 
        System.out.println("A área do triângulo é: " + t1.area());
    }
}
